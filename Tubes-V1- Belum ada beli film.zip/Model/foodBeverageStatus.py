from enum import Enum


class FoodBeverageStatus(Enum):
    UNREDEEMED = 0
    REDEEMED = 1