from enum import Enum

class ItemType(Enum):
    MOVIE = 0
    FOOD_AND_BEVERAGE = 1