class ReviewFilm:
    def __init__(self, score: int = 0, review:str = ""):
        self.score = score
        self.review = review