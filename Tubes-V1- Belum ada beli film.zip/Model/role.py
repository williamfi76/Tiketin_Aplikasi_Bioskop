from enum import Enum


class Role(Enum):
    ADMIN = 0
    EMPLOYEE = 1
    MEMBER = 2