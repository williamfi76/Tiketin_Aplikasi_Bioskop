from enum import Enum

class FoodBeverageType(Enum):
    FOOD = 0
    BEVERAGE = 1