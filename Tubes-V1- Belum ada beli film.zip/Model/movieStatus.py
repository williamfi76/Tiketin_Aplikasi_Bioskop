from enum import Enum

class MovieStatus(Enum):
    NOT_SHOWING = 0
    SHOWING = 1