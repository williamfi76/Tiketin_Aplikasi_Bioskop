def generateDummy():
    pass

def generateNewDummy():
    pass