from Controller import memberController
from Model.ticket import Ticket

tickets = []
tickets.append("A1")
tickets.append("A2")
tickets.append("A3")
tickets.append("A4")

memberController.buyTicket(7, 2, tickets)